module Main (main) where

import Control.Monad (unless)
import System.Exit (exitFailure)
import WordFreq

check :: (Eq a, Show a) => String -> a -> a -> IO Bool
check name expected actual
  | expected == actual = putStrLn ("PASS " ++ name) >> pure True
  | otherwise = putStrLn ("FAIL " ++ name ++ ": expected " ++ show expected ++ ", got " ++ show actual) >> pure False

main :: IO ()
main = do
  results <- sequence
    [ check "tokenize ignores case and punctuation"
        ["hello", "world", "it's"] (tokenize "Hello, WORLD! It's")
    , check "topN ranks by count"
        [("a", 3), ("b", 2)] (topN 2 "a b a c b a")
    , check "ties break alphabetically"
        [("apple", 1), ("pear", 1)] (topN 2 "pear apple")
    , check "empty input"
        [] (topN 5 "")
    ]
  unless (and results) exitFailure
