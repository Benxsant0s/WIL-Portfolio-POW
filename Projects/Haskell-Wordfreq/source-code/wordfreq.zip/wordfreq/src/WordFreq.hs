-- | Pure logic: turn text into a ranked list of (word, count).
module WordFreq
  ( tokenize
  , countWords
  , topN
  ) where

import Data.Char (isAlpha, toLower)
import Data.List (sortBy)
import qualified Data.Map.Strict as Map
import Data.Ord (Down (..), comparing)

-- | Lowercase the text and split it into words (letters and apostrophes only).
tokenize :: String -> [String]
tokenize = words . map clean
  where
    clean c
      | isAlpha c || c == '\'' = toLower c
      | otherwise              = ' '

-- | Count how many times each word appears.
countWords :: [String] -> Map.Map String Int
countWords = foldr (\w -> Map.insertWith (+) w 1) Map.empty

-- | The @n@ most frequent words, highest count first (ties sorted alphabetically).
topN :: Int -> String -> [(String, Int)]
topN n = take n . sortBy order . Map.toList . countWords . tokenize
  where
    order = comparing (Down . snd) <> comparing fst
