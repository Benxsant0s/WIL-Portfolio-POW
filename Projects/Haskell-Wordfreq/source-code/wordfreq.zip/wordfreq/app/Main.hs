module Main (main) where

import System.Environment (getArgs)
import System.Exit (die)
import Text.Read (readMaybe)
import WordFreq (topN)

main :: IO ()
main = do
  args <- getArgs
  case args of
    []         -> run 10 =<< getContents
    [file]     -> run 10 =<< readFile file
    [file, n]  -> case readMaybe n of
                    Just k  -> run k =<< readFile file
                    Nothing -> die "N must be a whole number"
    _          -> die "usage: wordfreq [FILE [N]]   (reads stdin if no FILE)"

run :: Int -> String -> IO ()
run n text = mapM_ (\(w, c) -> putStrLn (pad w ++ show c)) (topN n text)
  where pad w = w ++ replicate (15 - length w) ' '
