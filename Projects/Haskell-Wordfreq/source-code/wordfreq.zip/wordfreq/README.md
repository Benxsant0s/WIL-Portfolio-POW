# wordfreq

A tiny Haskell CLI that prints the most common words in a text.

## Setup
1. Install GHC and Cabal with GHCup: https://www.haskell.org/ghcup/
2. In this folder:

    cabal build
    cabal test
    cabal run wordfreq -- README.md 5
    echo "the cat and the hat and the bat" | cabal run -v0 wordfreq

## Layout
- `src/WordFreq.hs`  pure logic (tokenize, count, rank)
- `app/Main.hs`      command-line handling and printing
- `test/Spec.hs`     dependency-free tests
- `wordfreq.cabal`   project definition
